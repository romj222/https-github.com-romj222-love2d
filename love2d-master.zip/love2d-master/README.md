Tetirs Game 

Developed using Love2d framework
Game includes
1. Algo to produce difficult block - can be tweaked to play in a normal mode
2. Score 
3. Difficulty level based on the score


